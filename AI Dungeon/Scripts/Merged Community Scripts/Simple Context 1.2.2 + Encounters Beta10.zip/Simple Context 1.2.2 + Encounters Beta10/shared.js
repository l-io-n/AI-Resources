/*
 * Configuration
 */
const statsFormatterConfig = {
  order: ["Author's Note", "Scene", "Think", "Focus", "World Info"],
  alignVertical: true,
  truncateLabels: true,
  truncateSep: ""
}


/*
 * WorldInfo Tracking Plugin
 */
class TrackingPlugin {
  STAT_TEMPLATE = { key: "World Info", color: "goldenrod" }

  constructor() {
    if (!state.trackingPlugin) state.trackingPlugin = {
      isDisabled: false,
      isDebug: false
    }
    this.state = state.trackingPlugin
  }

  execute(text) {
    // Don't run if disabled
    if (this.state.isDisabled || !text) return

    // Gather context
    const frontLines = (state.memory.frontMemory || "").split("\n")
    const lines = text.split("\n").concat(frontLines)
    lines.reverse()

    // Go through each world info entry and check to see
    // if it can be found within the context provided
    const trackedKeys = []
    for (let idx = 0; idx < lines.length; idx++) {
      const match = worldInfo.find(i => i.entry === lines[idx])
      if (!match) continue
      const matchKey = match.keys.split(",")[0].trim()
      trackedKeys.push(this.state.isDebug ? `${matchKey} (${idx})` : matchKey)
    }

    this.displayStat(trackedKeys.join(", "))
  }

  displayStat(value) {
    const stat = state.displayStats.find(s => s.key === this.STAT_TEMPLATE.key)

    // If the value is valid, create/update stat
    if (value !== undefined && value !== "") {
      if (stat) stat.value = value
      else state.displayStats.push(Object.assign({ value }, this.STAT_TEMPLATE))
    }
    // Otherwise remove stat from list
    else if (stat) {
      state.displayStats = state.displayStats.filter(s => s.key !== this.STAT_TEMPLATE.key)
    }
  }
}
const trackingPlugin = new TrackingPlugin()


/*
 * Stats Formatter Plugin
 */
class StatsFormatterPlugin {
  constructor() {
    if (!state.displayStats) state.displayStats = []
    if (!state.statsFormatterPlugin) state.statsFormatterPlugin = {
      isDisabled: false,
      displayStats: []
    }
    this.state = state.statsFormatterPlugin
  }

  execute(options = {}) {
    // Set defaults
    options.order = options.order || []
    options.alignVertical = !!options.alignVertical
    options.truncateLabels = !!options.truncateLabels
    options.truncateSep = options.truncateSep || ""

    // Don't run if disabled
    if (this.state.isDisabled) return

    // Detect new stats and add them to state
    const existingKeys = this.state.displayStats.map(s => s.key)
    const newStats = state.displayStats.filter(s => s.key !== options.truncateSep && !existingKeys.includes(s.key))
    if (newStats.length) this.state.displayStats = this.state.displayStats.concat(newStats)

    // Detect stats that are updated
    const newStatsKeys = newStats.map(s => s.key)
    const updateStats = state.displayStats.filter(s => s.key !== options.truncateSep && !newStatsKeys.includes(s.key))
    if (updateStats.length) this.state.displayStats.map(stat => {
      for (let updateStat of updateStats) {
        if (updateStat.key === stat.key) {
          stat.value = updateStat.value
          return stat
        }
      }
      return stat
    })

    // Remove stats with undefined value
    this.state.displayStats = this.state.displayStats.filter(s => s.value !== undefined)

    // Do ordering
    const orderedStats = []
    for (let statName of options.order) {
      const stat = this.state.displayStats.find(s => s.key.toLowerCase() === statName.toLowerCase())
      if (stat) orderedStats.push(stat)
    }
    const orderedKeys = orderedStats.map(s => s.key)
    this.state.displayStats = orderedStats.concat(this.state.displayStats.filter(s => !orderedKeys.includes(s.key)))

    // Do formatting
    if (options.truncateLabels) {
      state.displayStats = this.state.displayStats.map(stat => Object.assign({}, stat, {
        key: options.truncateSep,
        value: stat.value + " :" + options.truncateSep + (options.alignVertical ? "\n" : "")
      }))
    } else {
      let allStatsButLast = this.state.displayStats.slice(0, -1)
      let suffix = options.alignVertical ? "\n" : " "
      allStatsButLast = allStatsButLast.map(s => Object.assign({}, s, {value: s.value + suffix}))
      state.displayStats = allStatsButLast.concat(this.state.displayStats.slice(-1))
    }
  }
}
const statsFormatterPlugin = new StatsFormatterPlugin()


/*
 * Simple Context Plugin
 */
class SimpleContextPlugin {
  STAT_STORY_TEMPLATE = { key: "Author's Note", color: "dimgrey" }
  STAT_SCENE_TEMPLATE = { key: "Scene", color: "lightsteelblue" }
  STAT_THINK_TEMPLATE = { key: "Think", color: "darkseagreen" }
  STAT_FOCUS_TEMPLATE = { key: "Focus", color: "indianred" }

  controlList = ["enable", "disable", "show", "hide", "reset", "debug"] // Plugin Controls
  commandList = [
    "note", "title", "author", "genre", "setting", "theme", "subject", "style", "rating", // Story
    "you", "at", "with", "time", "desc", // Scene
    "think", // Think
    "focus" // Focus
  ]
  commandMatch = /^> You say "\/(\w+)( [^"]+)?"$|^> You \/(\w+)( .*)?[.]$|^\/(\w+)( .*)?$/

  constructor() {
    this.commandList = this.controlList.concat(this.commandList)
    // Setup plugin state/scope
    if (!state.simpleContextPlugin) state.simpleContextPlugin = {
      isDebug: false,
      isHidden: false,
      isDisabled: false,
      shuffleContext: false,
      data: {},
      context: {}
    }
    this.state = state.simpleContextPlugin
    if (!state.displayStats) state.displayStats = []
  }

  /*
   * Helper Functions
   */
  isVisible() {
    return !this.state.isDisabled && !this.state.isHidden
  }

  appendPeriod(content) {
    return !content.endsWith(".") ? content + "." : content
  }

  removePeriod(content) {
    return content.endsWith(".") ? content.slice(0, -1) : content
  }

  toTitleCase(content) {
    return content.charAt(0).toUpperCase() + content.slice(1)
  }

  displayStat(template, value) {
    const stat = state.displayStats.find(s => s.key === template.key)
    if (stat) stat.value = value
    else state.displayStats.push(Object.assign({ value }, template))
  }

  updateHUD() {
    if (this.isVisible()) {
      state.trackingPlugin.isDisabled = false
      state.statsFormatterPlugin.isDisabled = false
      this.displayStat(this.STAT_STORY_TEMPLATE, this.state.context.story)
      this.displayStat(this.STAT_SCENE_TEMPLATE, this.state.context.scene)
      this.displayStat(this.STAT_THINK_TEMPLATE, this.state.context.think)
      this.displayStat(this.STAT_FOCUS_TEMPLATE, this.state.context.focus)
    } else {
      state.trackingPlugin.isDisabled = true
      state.statsFormatterPlugin.isDisabled = true
      state.displayStats = []
    }
  }

  /*
   * Returns: false, if new modified context exceeds 85% limit.
   * Where:
   *   originalSize is the length of the original, unmodified text.
   *   entrySize is the length of the world entry being inserted.
   *   totalSize is the total modfied size so far.
   */
  validEntrySize(originalSize, entrySize, totalSize) {
    if (originalSize === 0) return false
    const modifiedPercent = (totalSize + entrySize) / originalSize
    return modifiedPercent < 0.84
  }

  uniqueInOrder(values) {
    const result = [];
    const input = Array.isArray(values) ? values : values.split('');

    for (let i = 0; i < (input.length - 1); i++) {
      if (input[i] === input[i + 1]) continue
      result.push(input[i])
    }

    return result
  }

  /*
   * Input Handler
   * - Takes new command and refreshes context and HUD (if visible and enabled)
   * - Updates when valid command is entered into the prompt (ie, `/name John Smith`)
   * - Can clear state by executing the command without any arguments (ie, `/name`)
   */
  inputModifier(text) {
    // Check if no input (ie, prompt AI)
    if (!text) {
      this.state.shuffleContext = true
      return text
    }

    // Detection for multi-line commands, filter out double ups of newlines
    let modifiedText = text.split("\n").map(l => this.inputHandler(l)).join("\n")
      .replace(/[\n]{2,}/g, "\n")

    // Cleanup for multi commands
    if (modifiedText === "\n") modifiedText = ""

    return modifiedText
  }

  inputHandler(text) {
    // Check if a command was inputted
    let match = this.commandMatch.exec(text)
    if (match) match = match.filter(v => !!v)
    if (!match || match.length < 2) return text

    // Check if the command was valid
    const cmd = match[1].toLowerCase()
    const value = match.length > 2 && match[2] ? match[2].trim() : undefined
    if (!this.commandList.includes(cmd)) return text

    // Detect for Controls, handle state and perform actions (ie, hide HUD)
    if (this.controlList.includes(cmd)) {
      if (cmd === "debug") {
        this.state.isDebug = !this.state.isDebug
        state.trackingPlugin.isDebug = this.state.isDebug
        if (!this.state.isDebug) state.message = ""
        else if (this.isVisible()) state.message = "Enter something into the prompt to start debugging the context.."
      }
      else if (cmd === "enable" || cmd === "disable") this.state.isDisabled = (cmd === "disable")
      else if (cmd === "show" || cmd === "hide") this.state.isHidden = (cmd === "hide")
      else if (cmd === "reset") {
        this.state.context = {}
        this.state.data = {}
      }
      this.updateHUD()
      return
    } else {
      // If value passed assign it to the data store, otherwise delete it (ie, `/name`)
      if (value) this.state.data[cmd] = value
      else delete this.state.data[cmd]
    }

    // Story - Author's Notes, Title, Author, Genre, Setting, Theme, Subject, Writing Style and Rating
    const story = []
    delete this.state.context.story
    if (this.state.data.note) story.push(this.appendPeriod(this.state.data.note))
    if (this.state.data.title) story.push(`Title: ${this.appendPeriod(this.state.data.title)}`)
    if (this.state.data.author) story.push(`Author: ${this.appendPeriod(this.state.data.author)}`)
    if (this.state.data.genre) story.push(`Genre: ${this.appendPeriod(this.state.data.genre)}`)
    if (this.state.data.setting) story.push(`Setting: ${this.appendPeriod(this.state.data.setting)}`)
    if (this.state.data.theme) story.push(`Theme: ${this.appendPeriod(this.state.data.theme)}`)
    if (this.state.data.subject) story.push(`Subject: ${this.appendPeriod(this.state.data.subject)}`)
    if (this.state.data.style) story.push(`Writing Style: ${this.appendPeriod(this.state.data.style)}`)
    if (this.state.data.rating) story.push(`Rating: ${this.appendPeriod(this.state.data.rating)}`)
    if (story.length) this.state.context.story = story.join(" ")

    // Scene - Name, location, present company, time and scene description
    const scene = []
    delete this.state.context.scene
    if (this.state.data.you) scene.push(`You are ${this.appendPeriod(this.state.data.you)}`)
    if (this.state.data.at && this.state.data.with) scene.push(`You are at ${this.removePeriod(this.state.data.at)} with ${this.appendPeriod(this.state.data.with)}`)
    else if (this.state.data.at) scene.push(`You are at ${this.appendPeriod(this.state.data.at)}`)
    else if (this.state.data.with) scene.push(`You are with ${this.appendPeriod(this.state.data.with)}`)
    if (this.state.data.time) scene.push(`It is ${this.appendPeriod(this.state.data.time)}`)
    if (this.state.data.desc) scene.push(this.toTitleCase(this.appendPeriod(this.state.data.desc)))
    if (scene.length) this.state.context.scene = scene.join(" ")

    // Think - This input is placed six positions back in context
    delete this.state.context.think
    if (this.state.data.think) this.state.context.think = this.toTitleCase(this.appendPeriod(this.state.data.think))

    // Focus - This input is pushed to the front of context
    delete this.state.context.focus
    if (this.state.data.focus) this.state.context.focus = this.toTitleCase(this.appendPeriod(this.state.data.focus))

    // Display HUD
    this.updateHUD()

    return ""
  }

  /*
   * Context Injector
   * - Takes existing set state and dynamically injects it into the context
   * - Is responsible for injecting custom World Info entries and tracking them in the HUD
   * - Keeps track of the amount of modified context and ensures it does not exceed the 85% rule
   *   while injecting as much as possible
   */
  contextModifier(text) {
    if (this.state.isDisabled || !text) return text;

    const contextMemory = info.memoryLength ? text.slice(0, info.memoryLength) : ""
    const context = info.memoryLength ? text.slice(info.memoryLength) : text

    let totalSize = 0
    const originalSize = context.length
    const combinedState = (this.state.context.story || "") + (this.state.context.scene || "") +
      (this.state.context.think || "") + (this.state.context.focus || "")
    const lines = context.split("\n").filter(line => !!line)

    // Insert focus
    if (this.state.context.focus) {
      const entry = `[ ${this.state.context.focus}]`
      if (this.validEntrySize(originalSize, entry.length, totalSize)) {
        if (lines.length <= 1 || this.state.shuffleContext) lines.push(entry)
        else lines.splice(-1, 0, entry)
        totalSize += entry.length
      }
    }

    // Insert think
    if (this.state.context.think) {
      const entry = `[ ${this.state.context.think}]`
      if (this.validEntrySize(originalSize, entry.length, totalSize)) {
        const pos = this.state.shuffleContext ? 5 : 4
        if (lines.length <= pos) lines.unshift(entry)
        else lines.splice((pos * -1), 0, entry)
        totalSize += entry.length
      }
    }

    // Build header
    const header = []

    // Build character and scene information
    if (this.state.context.scene) {
      const entry = `[ ${this.state.context.scene}]`
      if (this.validEntrySize(originalSize, entry.length, totalSize)) {
        header.push(entry)
        totalSize += entry.length
      }
    }

    // Build author's note
    if (this.state.context.story) {
      const entry = `[Author's note: ${this.state.context.story}]`
      if (this.validEntrySize(originalSize, entry.length, totalSize)) {
        header.push(entry)
        totalSize += entry.length
      }
    }

    // Load your character world info first

    if (this.state.data.you) {
      const youInfo = worldInfo.filter(info => info.keys.split(",").map(key => key.trim()).includes(this.state.data.you))
      for (let info of youInfo) {
        if (!context.includes(info.entry) && this.validEntrySize(originalSize, info.entry.length, totalSize)) {
          header.push(info.entry)
          totalSize += info.entry.length
        }
      }
    }

    // Build world info entries by matching keys to combinedState
    const detectedInfo = worldInfo.filter(i => !context.includes(i.entry) && !header.includes(i.entry))
    for (let info of detectedInfo) {
      const keys = info.keys.split(",").map(key => key.trim())
      for (let key of keys) {
        // Already loaded
        if (header.includes(info.entry)) break
        // See if combinedState has matching key
        if (combinedState.includes(key) && this.validEntrySize(originalSize, info.entry.length, totalSize)) {
          header.push(info.entry)
          totalSize += info.entry.length
        }
      }
    }

    // Insert header
    if (header.length) {
      const headerPos = this.state.shuffleContext ? 9 : 8
      if (lines.length <= headerPos) for (let line of header) lines.unshift(line)
      else {
        header.reverse()
        for (let line of header) lines.splice((headerPos * -1), 0, line)
      }
    }

    // Create new context
    const modifiedContext = lines.join("\n").slice(-(info.maxChars - info.memoryLength))

    // Debug output
    if (this.state.isDebug && this.isVisible()) {
      const debugLines = modifiedContext.split("\n")
      debugLines.reverse()
      state.message = debugLines.map((l, i) => `(${i + 1}) ${l.slice(0, 25)}..`).join("\n")
    }

    return [contextMemory, modifiedContext].join("")
  }
}
const simpleContextPlugin = new SimpleContextPlugin()


// BEGIN Encounters!

// local devving helpers:
/*
state = {
    encounterPersistence:{}
}
worldInfo = []
*/

const encounterSettings = {
    debugMode: false,
    importWI: true
}

// encounterDef database:
var encounterDB = {
    // hardcoded encounters:
    // one open encounter (=encounters that have chance) will be made current at a time only (from consideration, branches might do more)
    // closed encounters (=encounters without chance) can only become current through chaining
    // there is only one current encounter at a time, and open encounters are only considered if there is no current encounter
    // order in this object determines precedence!
    /* REMOVE THIS LINE AND THE ONE AT THE END OF encounterDB TO SEE THE EXAMPLE ENCOUNTERS IN ACTION
    waveRedFlag: {
        encounterID: "waveRedFlag",
        triggers: ["redflag"],
        chance: 100,
        countOccurrence: true, // count how often this encounter ENDED
        recurrenceLimit: 1, // recurrenceLimit is independent of countOccurrence (for now; beta9 dev 11.03.21)
        message: "The red flag is waved!",
        duration: 0,
    },
    waveGreenFlag: {
        encounterID: "waveGreenFlag",
        chance: 100,
        prerequisite: [['waveRedFlag', 1]], // ALL items must have occurred at least the specified number of times to allow encounter to become current
        message: "The green flag is waved!",
        duration: 0,
    },
    waveBlueFlag: {
        encounterID: "waveBlueFlag",
        chance: 100,
        blockers: [['waveRedFlag', 1]], // if any of the items have occurred at least the specified number of times, do not allow encounter to become current
        message: "The blue flag is waved!",
        duration: 0,
    },
    displayStuff: {
        encounterID:"displayStuff",
        chance:100,
        displayStatNotes:[["Bugs","{amount}","{color}"], ["Bugs",100,"red"]],
        duration:0
    },
    randoTest: {
        encounterID: "randoTest",
        chance: 100,
        activationDelay: [1, 2],
        duration: [2, 5],
        cooldown: [1, 6]
    }
    pickPebble:{
      encounterID:"pickPebble",
      triggers:["pick a pebble"],
      chance:100,
      branches:[
        {
          branchTriggers:["for your mate"],
          branchChance:100,
          branchTextNotes:["Your fellow {charClass} likes it!"], // wordlist placeholders work just like in the gauntlet script, and work on any textNotes
        },
        ],
      textNotes:["The pebble is {*color}, with {*color} {pattern}. There was another {*color} one with {*color} {*pattern} and {*color} {*pattern}."],
      // textNotes:["The pebble is {color}, with {color} {pattern}. There was another {color} one with {color} {pattern} and {color} {pattern}."],
      duration:0,
    },
    dragonAwake:{
      encounterID:"dragonAwake",
      chance:100,
      // memory insert, like World Events:
      // will be in order of encounters as they happen
      memoryAdd:{
        memoryText:"The ancient dragon has woken up.", // WARNING: This will *not* be visible to the player!
        memoryLocation:"top", // top = before player mem, bottom = after player mem; defaults to top
        memoryGreed:false, // safety thingy to prevent hijacking, compatibility; KEEP THIS false OR DO NOT EVEN PUT IT IN UNLESS YOU WANT TO BREAK THINGS! -> if set to true, the memoryText will just get shoved in there, even if it then gets cut off later
        memoryLingerDuration:10 // how long this sticks around after the encounter; World Event style
      },
      duration:0,
      cooldown:20, // better keep cooldown above memoryLingerDuration...
    },
    spotTheDevs:{
      encounterID:"spotTheDevs", // MUST match the encounterDB key!!! needed to limit encounters
      // lock checking:
      inputLock:false, // don't lock input checking; can be omitted
      outputLock:true, // but ignore AI outputs; can be omitted
      triggers:["code"],
      chance:100,
      duration:0,
      // adding WI:
      addWI:[{keys:"dev,latitude,nice people", entry:"The Latitude devs are nice people.", hidden:false}], // ...should work?; takes list, so can add more than one WI entry
      // limiting encounter recurrence
      recurrenceLimit:1, // this encounter can happen only one time
      textNotes:["You learn something about the devs..."] // text to be attached to the triggering (text), either input or output, depending on what triggered it
    },
    dance:{ // example for precedence, if 'you dance' while 'you enter a cave', only 'dance' happens, but not the goblinAttack stuff below; also an almost minimal encounterDef
      encounterID:"dance",
      totalActionDelay:0,
      triggers:["dance"],
      chance:100,
      duration:0,
      cooldown:5, // cooldown will start immediatly when encounter ends, so 1 for immediate cooldown, which is kinda redundant, but may be useful for testing; WARNING: due to how JS works (and lazyness), cooldown:0 will just not do anything.
      // weighted list: from lowest to highest, 1-100; function basically rolls a d100 and picks the first list item that fits:
      textNotesWeighted:[["You dance well.", 30],[`You "dance".`,70],[`You fall over.`,100],], // example: 30% chance for good dancing (0->30=30), 40% wobbling about (30->70=40), 30% derping out hard (70->100=30).
      // weighted lists work for all picking lists, but have to be defined as such (key ending in "Weighted") (for now, might add thingy that checks, but that entails hardcode...)
    },
    goblinAttackInit:{ // this is an 'initializer' encounter, it does nothing but trigger by itself and then chain into one of two random followup encounters
      encounterID:"goblinAttackInit", // to indentify type of current encounter;
      totalActionDelay:2, // info.actionCount needs to be higher than this to allow encounter triggering; always allow encounter if missing
      chance:100, // in percent; if missing, there is no chance for this encounter to occur unless chained; if triggers should always start this encounter, set chance to 100
      triggers:["(?<=(spot|see|find).*)goblin", "(?<=enter.*)(cave|warren|thicket)"], // trigger words: if found in text, set encounter; regEx possible!; if missing from encounterDef, it will trigger based on chance alone!
      activationDelay:0, // how many actions after triggering this starts it's thing; can be omitted
      duration:0, // how many actions this sticks around; if there is no duration, encounter is endless, only ended by endTriggers; duration 0 leads to immediate end, for chaining
      // CHAINING
      // list of follow-up encounters! BD
      // chained:['goblinAttackRocks', 'goblinAttackHorde'] <- example for non-weighted list
      chained:[['goblinAttackRocks',60], ['goblinAttackHorde',100]]
    },
    goblinAttackRocks:{
      encounterID:"goblinAttackRocks", // to indentify type of current encounter
      duration:3, // how many actions this sticks around; if there is no duration, encounter is endless, only ended by endTriggers; duration 0 leads to immediate end, for chaining
      endTriggers:["(?<=(hit|kill|scare).*)goblin","/(?<=you.*).+(((leave|escape|flee).*)(?!=you.*)(cave|warren|thicket))"], // to end the encounter based on (text); soft-required for no-duration/infinite encounters
      messageString:"Goblin attack!", // to be shown in state.message; optional
      contextNotes:["[You are suddenly attacked by a goblin!]","[A single goblin throws rocks at you.]"], // what's shown to the AI; one gets picked at random when the encounter is started; goes below AN in context
      textNotes:["A goblin starts throwing rocks at you."],
      chained:['goblinEscape1',]
    },
    goblinEscape1:{
      encounterID:"goblinEscape1", // to indentify type of current encounter
      inputLock:true,
      duration:3, // how many actions this sticks around
      messageString:"Goblin flees!", // to be shown in state.message
      contextNotes:["[The goblin stops throwing rocks at you.]"], // what's shown to the AI; one gets picked at random when the encounter is run
      textNotes:["The goblin stops throwing rocks at you and runs away."]
    },
    goblinAttackHorde:{
      encounterID:"goblinAttackHorde", // to indentify type of current encounter
      inputLock:true,
      messageString:"Goblin attack!", // to be shown in state.message; optional
      contextNotes:["[A horde of goblins is attacking you!]","[You are being attacked by goblins!]",], // what's shown to the AI; one gets picked at random when the encounter is run; optional
      textNotes:["A horde of goblins starts attacking you.",],// optional
      branches:[
        {
          branchID:'impressive',
          branchTriggers:["impress the goblins"], // basically like endTriggers, but with individual chained
          branchChance:100, // to keep things parallel; this means branches NEED it
          branchChained:['becomeGoblinChief'],
        },
        {
          branchID:'dragonScare',
          branchChance:5, // to keep things parallel
          branchTextNotes:["The goblins run away in panic as a dragon arrives!"], // to be immediately inserted; does not wait for chained encounter activation!; keeping branches compact, so leave out other inserts
          branchChained:['dragonAttack'],
        },
        ],
      endTriggers:["(?<=(hit|kill|scare).*)goblin","/(?<=you.*).+(((leave|escape|flee).*)(?!=you.*)(cave|warren|thicket))"], // to end the encounter based on (text); soft-required for no-duration/infinite encounters
      chained:['goblinEscapeHorde',]
    },
    becomeGoblinChief:{
      encounterID:"becomeGoblinChief", // to indentify type of current encounter
      inputLock:true,
      duration:0, // how many actions this sticks around
      messageString:"Goblins make you chief!", // to be shown in state.message
      textNotes:["The goblins are so impressed by you that they make you their chief."],
      addWI:[{keys:"goblin", entry:"You are the goblin chief.", hidden:false}],
    },
    goblinEscapeHorde:{
      encounterID:"goblinEscapeHorde", // to indentify type of current encounter
      inputLock:true,
      duration:3, // how many actions this sticks around
      messageString:"Goblins flee!", // to be shown in state.message
      contextNotes:["[The horde of goblins is running away!]","[The goblins are suddenly running away!]"], // what's shown to the AI; one gets picked at random when the encounter is run
      textNotes:["The horde of goblins runs away."]
    },
    dragonAttack:{
      encounterID:"dragonAttack", // to indentify type of current encounter
      inputLock:true,
      duration:3, // how many actions this sticks around
      messageString:"Dragon attack!", // to be shown in state.message
      contextNotes:["A dragon is burning down everything!"], // what's shown to the AI; one gets picked at random when the encounter is run
      textNotes:["Suddenly, a dragon burns down everything.","Suddenly, a dragon shows up!"]
    },
    weather:{ // was once a minimal encounterDef; last in object to not prevent other encounters
      encounterID:"weather",
      chance:50, // 50% chance to happen every action
      branches:[
        {
          branchID:'goodKid',
          branchTriggers:["finish your plate"], // basically like endTriggers, but with individual chained possible
          branchChance:100, // to keep things parallel; this means branches NEED it
          branchTextNotes:["It's sunny!"],
          branchChained:[], // you can stop the current encounter doing this
        },
      ],
      duration:0,
      chained:['badWeather']
    },
    badWeather:{ // super minimal encounterDef: puts in note, then poofs
      encounterID:"badWeather",
      duration:0,
      textNotes:["It's rainy.","It's cloudy."],
    }
    */ // REMOVE THIS LINE AND THE ONE AT THE START OF encounterDB TO SEE THE EXAMPLE ENCOUNTERS IN ACTION
}

// word list stuff like gauntlet script:
var encounterWordLists = {
    /* Remove this line (and the one below) to enable the example word lists
    charClass:["mage","fighter","valkyrie"],
    pattern:["sprinkles", "dots", "lines"],
    color:["red","blue","green","yellow","orange"],
    amount:["many","few","all of them"]
     */ // Remove this line (and the one above) to enable the example word lists
}

// WI data imports:
if (encounterSettings.importWI) {
    for (WIentry of worldInfo) {
        // encounters from WI:
        // these will be lower priority then the hardcoded ones above!
        if (WIentry.keys.includes('#encounterDef')) {
            let encounterDefFromWI = JSON.parse(WIentry.entry)
            encounterLog(`Found WI encounterDef for '${encounterDefFromWI.encounterID}', adding it to the DB!`)
            encounterDB[encounterDefFromWI.encounterID] = encounterDefFromWI
        }
        // word lists from WI:
        if (WIentry.keys.includes('#encounterWordListsFull')) {
            let encounterWordListsFromWI = JSON.parse(WIentry.entry)
            encounterLog(`Found full WI encounterWordLists entry, adding them to the DB!`)
            for (let encounterSingleWordList in encounterWordListsFromWI) {
                encounterWordLists[encounterSingleWordList] = Object.values(encounterWordListsFromWI[encounterSingleWordList])
            }
        }
        if (WIentry.keys.includes('#encounterWordListSingle')) {
            let encounterWordListSingleFromWI = JSON.parse(WIentry.entry)
            encounterLog(`Found WI encounterWordList, adding it to the DB!`)
            encounterWordLists[Object.keys(encounterWordListSingleFromWI)[0]] = Object.values(encounterWordListSingleFromWI)
        }
    }
}

// encounter functions: (DON'T MESS WITH THESE!)
function updateCurrentEncounter(encounterUpcoming) {
    // ends, then sets or clears currentEncounter; if argument empty, clears current encounter
    // encounter end effects:
    if (state.currentEncounter) {
        // recurrenceLimit:
        if (state.currentEncounter.recurrenceLimit) {
            if (!state.encounterPersistence) {
                state.encounterPersistence = {}
            }
            if (!state.encounterPersistence.limited) {
                state.encounterPersistence.limited = []
                state.encounterPersistence.limited.push([state.currentEncounter.encounterID, state.currentEncounter.recurrenceLimit - 1])
            } else {
                for (let limiter of state.encounterPersistence.limited) {
                    if (limiter[0] === state.currentEncounter.encounterID) {
                        encounterLog(`'${state.currentEncounter.encounterID}' recurrence already has a limit.`)
                        if (limiter[1] > 0) {
                            limiter[1] = limiter[1] - 1
                        }
                    } else {
                        state.encounterPersistence.limited.push([state.currentEncounter.encounterID, state.currentEncounter.recurrenceLimit - 1])
                    }
                }
            }
        }
        // cooldowns:
        if (state.currentEncounter.cooldown) {
            if (!state.encounterPersistence) {
                state.encounterPersistence = {}
            }
            if (!state.encounterPersistence.cooldowns) {
                state.encounterPersistence.cooldowns = []
            }
            state.encounterPersistence.cooldowns.push([state.currentEncounter.encounterID, state.currentEncounter.cooldown])
        }
        // occurrence counting:
        if (state.currentEncounter.countOccurrence) {
            if (!state.encounterPersistence) {
                state.encounterPersistence = {}
            }
            if (!state.encounterPersistence.counts) {
                state.encounterPersistence.counts = []
                state.encounterPersistence.counts.push([state.currentEncounter.encounterID, 1])
            } else countsChecker: {
                for (let count of state.encounterPersistence.counts) {
                    if (count[0] === state.currentEncounter.encounterID) {
                        encounterLog(`'${state.currentEncounter.encounterID}' already has a occurrence count.`)
                        count[1] += 1
                        break countsChecker
                    }
                }
                state.encounterPersistence.counts.push([state.currentEncounter.encounterID, 1])
            }
        }
        // adding memories:
        if (state.currentEncounter.memoryAdd) {
            if (!state.encounterPersistence) {
                state.encounterPersistence = {}
            }
            if (!state.encounterPersistence.memories) {
                state.encounterPersistence.memories = []
            }
            state.encounterPersistence.memories.push(state.currentEncounter.memoryAdd)
        }
    }
    if (encounterUpcoming) {
        encounterLog(`Setting current encounter to '${encounterUpcoming}'.`)
        state.currentEncounter = encounterDB[encounterUpcoming]
        // random initial values handling:
        const randomizables = ['duration', 'activationDelay', 'cooldown']
        for (let encounterValue of randomizables) {
            if (typeof (state.currentEncounter[encounterValue]) !== 'undefined') {
                if (typeof (state.currentEncounter[encounterValue]) !== 'number' && state.currentEncounter[encounterValue].length === 2) {
                    encounterLog(`${encounterUpcoming} has random ${encounterValue}: ${state.currentEncounter[encounterValue]}`)
                    state.currentEncounter[encounterValue] = getRndInteger(state.currentEncounter[encounterValue][0], state.currentEncounter[encounterValue][1])
                    encounterLog(`${encounterUpcoming} random ${encounterValue} set to ${state.currentEncounter[encounterValue]}`)
                }
            }
        }
    } else {
        encounterLog("Clearing current encounter.")
        delete state.currentEncounter
    }
}

function updateCurrentEffects() { // 'activates' currentEncounter; or clears encounter effects if there is no active encounter
    if (state.currentEncounter) {
        if (state.currentEncounter.messageString) {
            state.message = fillPlaceholders(state.currentEncounter.messageString)
        }
        if (state.currentEncounter.contextNotes) {
            if (!state.encounterPersistence) {
                state.encounterPersistence = {}
            }
            state.encounterPersistence.contextNote = fillPlaceholders(getRndFromList(state.currentEncounter.contextNotes))
        }
        if (state.currentEncounter.displayStatNotes) {
            displayStatsUpdate(getRndFromList(state.currentEncounter.displayStatNotes))
        }
		// Allows defining "simpleContext" in the encounters, effectively allowing encounters to act as "rooms" and "scenes". Credit goes to Shea Valentine
		if (state.currentEncounter.simpleContext) {
            simpleContextPlugin.inputModifier(state.currentEncounter.simpleContext)
        }
    } else {
        delete state.message
        if (state.encounterPersistence) {
            if (state.encounterPersistence.contextNote) {
                delete state.encounterPersistence.contextNote
            }
        }


    }
}

function flowCheck(encounter) {

    if (encounterDB[encounter].cooldown) {
        if (typeof (state.encounterPersistence?.cooldowns) !== 'undefined') {
            for (let cooldown of state.encounterPersistence?.cooldowns) {
                if (cooldown[0] === encounter) {
                    encounterLog(`'${encounter}' has an active cooldown.`)
                    return false
                }
            }
        }
    }

    if (encounterDB[encounter].prerequisite) {
        encounterLog(`'${encounterDB[encounter].encounterID}' has prerequisites: ${encounterDB[encounter].prerequisite}`)
        if (typeof (state.encounterPersistence) !== 'undefined') {
            if (state.encounterPersistence?.counts) {
                prerequisiteLoop:
                    for (let prerequisite of encounterDB[encounter].prerequisite) {
                        encounterLog(`Looking for '${encounterDB[encounter].encounterID}' prerequisite '${prerequisite[0]}'...`)
                        for (let count of state.encounterPersistence?.counts) {
                            if (count[0] === prerequisite[0]) {
                                encounterLog(`Found '${encounterDB[encounter].encounterID}' prerequisite '${prerequisite[0]}', checking count...`)
                                if (count[1] >= prerequisite[1]) {
                                    encounterLog(`'${encounterDB[encounter].encounterID}' prerequisite '${prerequisite[0]}' count high enough!`)
                                    continue prerequisiteLoop
                                } else {
                                    encounterLog(`'${encounterDB[encounter].encounterID}' prerequisite '${prerequisite[0]}' count too low!`)
                                    return false
                                }
                            }
                        }
                        encounterLog(`Couldn't find '${encounterDB[encounter].encounterID}' prerequisite '${prerequisite[0]}'.`)
                        return false
                    }
            } else {
                encounterLog(`'${encounterDB[encounter].encounterID}' has prerequisites, but there are no counted occurrences.`)
                return false
            }
        } else {
            encounterLog(`'${encounterDB[encounter].encounterID}' has prerequisites, but there is no encounter persistence.`)
            return false
        }
    }

    if (encounterDB[encounter].blockers) {
        encounterLog(`'${encounterDB[encounter].encounterID}' has blockers: ${encounterDB[encounter].blockers}`)
        if (typeof (state.encounterPersistence) !== 'undefined') {
            if (state.encounterPersistence?.counts) {
                for (let blocker of encounterDB[encounter].blockers) {
                    encounterLog(`Looking for '${encounterDB[encounter].encounterID}' blocker '${blocker[0]}'...`)
                    for (let count of state.encounterPersistence?.counts) {
                        if (count[0] === blocker[0]) {
                            encounterLog(`Found '${encounterDB[encounter].encounterID}' blocker '${blocker[0]}', checking count...`)
                            if (count[1] >= blocker[1]) {
                                encounterLog(`'${encounterDB[encounter].encounterID}' blocker '${blocker[0]}' count too high!`)
                                return false
                            } else {
                                encounterLog(`'${encounterDB[encounter].encounterID}' blocker '${blocker[0]}' count low enough!`)
                            }
                        }
                    }
                    encounterLog(`Couldn't find '${encounterDB[encounter].encounterID}' blocker '${blocker[0]}'.`)
                }
            } else {
                encounterLog(`'${encounterDB[encounter].encounterID}' not blocked, as there are no counted occurrences.`)
            }
        } else {
            encounterLog(`'${encounterDB[encounter].encounterID}' not blocked, as there is no encounter persistence.`)
        }
    }

    if (typeof (encounterDB[encounter].totalActionDelay) == 'undefined') {
        encounterLog(`No global delay on '${encounterDB[encounter].encounterID}'!`)
        totalActionDelay = 0
    } else {
        totalActionDelay = encounterDB[encounter].totalActionDelay
    }
    if (info.actionCount < totalActionDelay) {
        encounterLog(`It's too early for '${encounterDB[encounter].encounterID}'.`)
        return false
    }
    encounterLog(`Hit more then ${totalActionDelay} total actions, allowing '${encounter}'!`)

    return true
}

function chainHandler(chainedEncounters) {
    let tempChained = [...chainedEncounters]
    encounterLog(`Created temporary chaining list: '${tempChained}'`)
    for (chainedEncounter of tempChained) {
        encounterLog(`Checking '${chainedEncounter}'...`)
        if (chainedEncounter.length === 1) {
            if (!flowCheck(chainedEncounter)) {
                encounterLog(`'${chainedEncounter}' is stopped by flow control!`)
                tempChained.splice(tempChained.indexOf(chainedEncounter), 1)
            }
        } else if (chainedEncounter.length === 2) {
            if (!flowCheck(chainedEncounter[0])) {
                encounterLog(`'${chainedEncounter}' is stopped by flow control!`)
                tempChained.splice(tempChained.indexOf(chainedEncounter), 1)
            }
        }
    }
    encounterLog(`Temporary chaining list after flow control: '${tempChained}'`)
    if (tempChained === []) {
        encounterLog(`Warning: Temporary chained list '${tempChained}' is empty, thus ending current encounter without chaining! This can happen if all chained encounters are stopped by flow control.`)
    }
    let pickedChainedEncounter = getRndFromList(tempChained)
    return (pickedChainedEncounter)
}

function fillPlaceholders(placeHolderString) {
    let curPlaceholderMatches = placeHolderString.match(/\{(.*?)\}/g)
    if (curPlaceholderMatches) {
        encounterLog(`Matched placeholders: ${curPlaceholderMatches}`)
        for (let placeholder of curPlaceholderMatches) {
            encounterLog(`Current placeholder: ${placeholder}`)
            if (placeholder[1] === '*') {
                encounterLog(`Current placeholder ${placeholder} contains a *, checking temporary word lists...`)
                placeholder = placeholder.replace(/(\*|{|})/gi, '')
                if (typeof (tempWordLists) == 'undefined') {
                    tempWordLists = {}
                }
                if (!tempWordLists[placeholder] || tempWordLists[placeholder].length === 0) {
                    encounterLog(`${placeholder} temporary wordlist is either non-existant or empty! Getting a new one.`)
                    tempWordLists[placeholder] = JSON.parse(JSON.stringify(encounterWordLists[placeholder]))
                }
                encounterLog(`Current temporary word lists:${tempWordLists}`)
                for (let insertTag in tempWordLists) {
                    if (placeholder.includes(insertTag)) {
                        encounterLog(`Found fitting placeholder tag in temporary list: ${insertTag}`)
                        let pickedInsert = getRndFromList(tempWordLists[insertTag])
                        encounterLog(`Randomly picked placeholder insert from temporary list: ${pickedInsert}`)
                        let insertRegEx = new RegExp(`{\\*${insertTag}}`,)
                        placeHolderString = placeHolderString.replace(insertRegEx, pickedInsert)
                        tempWordLists[placeholder].splice(tempWordLists[placeholder].indexOf(pickedInsert), 1)
                    }
                }
            } else {
                for (let insertTag in encounterWordLists) {
                    if (placeholder.includes(insertTag)) {
                        encounterLog(`Found fitting placeholder tag: ${insertTag}`)
                        let pickedInsert = getRndFromList(encounterWordLists[insertTag])
                        encounterLog(`Randomly picked placeholder insert: ${pickedInsert}`)
                        let insertRegEx = new RegExp(`{${insertTag}}`,)
                        placeHolderString = placeHolderString.replace(insertRegEx, pickedInsert)
                    }
                }
            }
        }
        delete tempWordLists
    }
    return (placeHolderString)
}

function encounterLog(msg) {
    if (encounterSettings.debugMode === true) {
        console.log(msg)
    }
}

// misc helper functions:
// get random
function getRndInteger(min, max) {
    return Math.floor(Math.random() * (max - min)) + min
}

// list-picker, dynamically handles weighted lists
function getRndFromList(list) {
    if (list[0]) {
        if (list[0].length === 2) {
            encounterLog(`${list} looks like a weighted list, doing that!`)
            return (getRndFromListWeighted(list))
        } else {
            encounterLog(`${list} looks like a plain list with ${list.length} item(s), simply picking from it!`)
            return (list[getRndInteger(0, list.length)])
        }
    } else {
        return ('')
    }
}

// list picker for lists with weighted items:
// currently works kinda like oldschool D&D encounter lists
function getRndFromListWeighted(weightedList) {
    let cutOff = getRndInteger(1, 100)
    encounterLog(`Picking from weighted list, cutoff: ${cutOff}`)
    for (let item of weightedList) {
        encounterLog(`'${item[0]}' threshold: ${item[1]}.`)
        if (cutOff <= item[1]) {
            encounterLog(`'${item[0]}' cutoff below threshold, picking it!`)
            return item[0]
        }
    }
}

// displayStats handling:
function displayStatsUpdate([inKey, inValue, inColor]) {
    // if key already exists, update; else push new entry; if no value given, removes displayStat entry matching key, if it exists
    if (!state.displayStats) {
        state.displayStats = []
    }
    let displayStatUpdated = false
    for (let displayStat of state.displayStats) {
        encounterLog(`Checking '${displayStat.key}' displayStats entry...`)
        let curDisplayStatIndex = state.displayStats.indexOf(displayStat)
        if (displayStat.key === inKey || displayStat.key === '\n' + inKey) {
            encounterLog(`Found '${inKey}' displayStats entry: ${state.displayStats[curDisplayStatIndex].key}, ${state.displayStats[curDisplayStatIndex].value}, ${state.displayStats[curDisplayStatIndex].color}, updating!`)
            if (inValue) {
                if (typeof (inValue) == 'string') {
                    inValue = fillPlaceholders(inValue)
                    encounterLog(`Value to update displayStat entry inputted: '${inValue}', updating.`)
                    state.displayStats[curDisplayStatIndex].value = inValue
                } else {
                    encounterLog(`Value to update displayStat entry inputted: '${inValue}', updating.`)
                    state.displayStats[curDisplayStatIndex].value = inValue
                }
            } else {
                encounterLog(`No value to update displayStat inputted, removing entry.`)
                state.displayStats.splice(curDisplayStatIndex, 1)
                displayStatUpdated = true
                break
            }
            if (inColor) {
                state.displayStats[curDisplayStatIndex].color = fillPlaceholders(inColor)
            }
            displayStatUpdated = true
            break
        }
    }
    if (displayStatUpdated === false) {
        encounterLog(`No ${inKey} displayStats entry found, adding it!`)
        if (state.displayStats.length > 0) {
            inKey = '\n' + inKey
        }
        state.displayStats.push({'key': inKey, 'value': inValue, 'color': inColor})
    }
}

// END Encounters